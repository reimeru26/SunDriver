"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: reading a file
"""

infile = 'day1.dat' # file name

myin = open(infile, 'r')  # open a text file in read modus
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

print( mytext[0] )  # check the list / print the first line
del mytext[0]   # remove header line from list