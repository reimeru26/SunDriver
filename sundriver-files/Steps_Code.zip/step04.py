"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: reading a file
Step 2: Converting text to numbers
Step 3: Collect numbers in lists
Step 4: Calculate sums per day
"""

infile = 'day1.dat' # file name

myin = open(infile, 'r')  # open a text file in read modus
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

del mytext[0]   # remove header line from list

### Step 2
# example

### Step 3
rawmin = []     # minutes - integer
rawpow = []     # power in W - integer
rawspeed = []   # speed in km/h - float
# Each entry in these lists will be for one minute.

for a in mytext:
    b = a.split(';')                    # split line of text into numbers
    rawmin.append( int(b[0]) )          # convert first text into integer an append it to list of minutes
    rawpow.append( int(b[1]) )          # convert second text into integer an append it to list of power
    rawspeed.append( float(b[2]) )      # convert third text into float an append it to list of speed
    
# sum over all power
p = 0.0
for a in rawpow:
    p = p + a / 60.0     # power in Wh / 60 min = 1 hour

# calculate distance in km
dist = 0
for a in rawspeed:
    dist = dist + a / 60.0 #  60 min = 1 hour

# output
s = 'Total power consumption of scooter for one day in W h ' + '\n' + str(p)
print(s)
s = 'Total range of scooter for one day in km ' + '\n' + str(dist)
print(s)