"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: reading a file
Step 2: Converting text to numbers
"""

infile = 'day1.dat' # file name

myin = open(infile, 'r')  # open a text file in read modus
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

del mytext[0]   # remove header line from list

### Step 2
# example
a = mytext[470]     # we choose entry number 470 because we need to see some numbers that are not zero
b = a.split(';')    # splitting the line into separate numbers -> b is now a list containing the numbers as text

print(b)        # see how it looks like
c = int(b[0])   # convert text to a number -> here integer
print(c)        # this is our first number

