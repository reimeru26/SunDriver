import step07

# initialization
m = step07.myfiles
step07.readweek(m)


# check results
print('day  power  distance')
for a in range(7):
    b = step07.getday(a)
    print(a, b[0], b[1])
    
    
    
    