"""
This is an example script for the lecture "Modelling and Simulation".
Introduction of simple plots

Uwe Reimer, Emden, November 2025
"""

import matplotlib.pyplot as plt


### This section is for plotting
pngfile = 'Markers.png' # file name for output

fwidth = 20                # figure width in cm 
fwidth = fwidth / 2.54        # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
plt.subplots( figsize=( fwidth,fheight ) ) 

plt.scatter(1,1,marker=".", color='#1155cc') 
plt.scatter(2,3,marker="s", color='#1155cc') 
plt.scatter(3,4,marker="*", color='#1155cc') 
plt.scatter(4,5,marker="x", color='#1155cc') 
plt.scatter(5,4,marker="X", color='#1155cc')
plt.scatter(6,3,marker="D", color='#1155cc')
plt.scatter(7,4,marker="v", color='#1155cc')  
plt.scatter(8,4,marker="^", color='#1155cc')  
plt.scatter(9,4,marker="<", color='#1155cc')  
plt.scatter(10,4,marker=">", color='#1155cc')   
plt.scatter(1,4,marker="*", color='seagreen')    

plt.xlabel('x data')   # label x-axis
plt.ylabel('y data')   # label y-axis

plt.savefig(pngfile)   # create file for output

""" 
markers:  "." point "," pixel "v" triangle down  ( "^" "<" ">" )
          "s" square "*" star "x" x  "X" x filled  "D" diamond
"""