"""
This is an example script for the lecture "Modelling and Simulation".
Introduction of simple plots

Uwe Reimer, Emden, November 2025
"""

import matplotlib.pyplot as plt

### x-y data
xdat = range(10)     # a list with integers from zero to 10
ydat = range(0,20,2) # a list from zero to 20 with step 2

### This section is for plotting
pngfile = 'Plot02.png' # file name for output

#plt.plot(xdat, ydat)   # line plot
plt.scatter(xdat, ydat)   # dots

plt.xlabel('x data')   # label x-axis
plt.ylabel('y data')   # label y-axis

plt.savefig(pngfile)   # create file for output

