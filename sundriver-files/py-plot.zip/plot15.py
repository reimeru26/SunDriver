"""
This is an example script for the lecture "Modelling and Simulation".
Introduction of simple plots

Uwe Reimer, Emden, November 2025
"""

import matplotlib.pyplot as plt
import random


xdat = range(10)
y1dat = []
y2dat = []
y3dat = []

for x in xdat:
    a = 5.0 + 5.0 * random.random() # Returns a random floating point number between 0 and 1
    y1dat.append(a)
    a = 6.0 + 5.0 * random.random()
    y2dat.append(a)
    a = 4.0 + 5.0 * random.random() 
    y3dat.append(a)
    

### This section is for plotting
pngfile = "Plot15.png"                      # file name for output

fwidth = 10                 # figure width in cm 
fwidth = fwidth / 2.54        # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
plt.subplots( figsize=( fwidth,fheight ) ) 

plt.plot(xdat, y1dat, label="y1", color='red')         # line plot data1
plt.plot(xdat, y2dat, label="y2", color='green')         # line plot data2
plt.plot(xdat, y3dat, label="y3", color='blue')

plt.scatter(xdat, y1dat, color='red')       
plt.scatter(xdat, y2dat, color='green')       
plt.scatter(xdat, y3dat, color='blue')

plt.xlabel("time step")       # label x-axis
plt.ylabel("y-value")         # label y-axis

plt.legend(loc='lower left', shadow=True)   # place legend - needs label in plots
plt.tight_layout()                          # optimize placement
plt.savefig(pngfile)                        # create fiel for output

