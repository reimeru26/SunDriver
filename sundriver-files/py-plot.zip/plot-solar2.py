"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

"""
file1 = 'emden.txt'
file2 = 'kochi.txt'

emdenx = []
emdeny = []
kochix = []
kochiy = []

# read first file -> Emden
myin = open(file1, 'r')     # open a text file in read mode
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

for a in mytext:
        b = a.split(' ')
        x = float( b[0] )
        y = float( b[1] )
        emdenx.append(x)
        emdeny.append(y)

# read second file -> Kochi
myin = open(file2, 'r')     # open a text file in read mode
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

for a in mytext:
        b = a.split(' ')
        x = float( b[0] )
        y = float( b[1] )
        kochix.append(x)
        kochiy.append(y)
        
### finished reading data, now start plotting ###


import matplotlib.pyplot as plt
pngfile = "solar-Emden.png"                     # file name for output

fwidth = 10                 # figure width in cm 
fwidth = fwidth / 2.54        # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
plt.subplots( figsize=( fwidth,fheight ) )

plt.fill_between(emdenx, emdeny, 0, color='yellow')
plt.scatter(emdenx, emdeny, marker="*", color='gold')   # scatter plot

plt.xlabel("month")         
plt.ylabel("PV energy in Wh")

plt.xlim(0.5,12.5)
plt.ylim(0,170000)

plt.tight_layout()    # optimize placement
plt.savefig(pngfile)    