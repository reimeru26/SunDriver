"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, December 2025

"""
import batterysolar as batsol   # model for battery of PV panel
import batteryscooter as batsco # model for battery of scooter
import solar                    # model for PV panel
import scooter                  # model for scooter

import matplotlib.pyplot as plt

filescooter = [ 'day1.dat', 'day2.dat', 'day3.dat', 'day4.dat', 'day5.dat', 'day6.dat', 'day7.dat']
filesolar = ['Kochi-2023.csv', 'Emden-2023.csv']

# initialize models, read files
solar.readyear(filesolar[0])  # we choose data / 0 = Kochi and 1 = Emden

scooter.readweek(filescooter) # read driving cycle for scooter
batsco.capa = batsco.capamax  # we start with a fully charged scooter
batsco.state = 100.0

### System data collection ###
pvpro = []      # PV production per day
chargesco = []  # charge battery scooter
statepv = []    # state battery solar (min value)
statesco = []   # state battery scooter (min value)

### START to read the data for one year ###
d = 0
w = 0
while d < 365:
    d = d + 1   # day of the year
    w = w + 1   # day of the week
    
    sol = solar.getday(d)   # solar power in Wh for each day (for 1 kW system)
    pvpro.append(sol)       # store PV production
    
    # first, we charge solar battery
    a = batsol.charge(sol)
    
    # second, the scooter is driving with it's own battery
    p = scooter.getday(w)
    batsco.discharge(p[0])
    a = batsco.state
    statesco.append(a)   # store min state of battery scooter
    
    if w > 6:       # one week has 0..6 days
        w = 0
          
### END to read the data for one year ###

# check if OK this should be 365
print( len(pvpro) )
print( len(statesco) )