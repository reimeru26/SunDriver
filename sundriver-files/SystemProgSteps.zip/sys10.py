"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, December 2025

"""
import batterysolar as batsol   # model for battery of PV panel
import batteryscooter as batsco # model for battery of scooter
import solar                    # model for PV panel
import scooter                  # model for scooter

import matplotlib.pyplot as plt

filescooter = [ 'day1.dat', 'day2.dat', 'day3.dat', 'day4.dat', 'day5.dat', 'day6.dat', 'day7.dat']
filesolar = ['Kochi-2023.csv', 'Emden-2023.csv']

# initialize models, read files
solar.readyear(filesolar[1])  # we choose data / 0 = Kochi and 1 = Emden

scooter.readweek(filescooter) # read driving cycle for scooter
batsco.capa = batsco.capamax  # we start with a fully charged scooter
batsco.state = 100.0

### System data collection ###
pvpro = []      # PV production per day
chargesco = []  # charge battery scooter
statepv = []    # state battery solar (min value)
statesco = []   # state battery scooter (min value)

### Control parameters ###
sizepv = 100.0 / 1000.0       # size of PV system in kW  results Kochi = 50 and Emden = 300

### START to read the data for one year ###
d = 0
w = 0
while d < 365:
    d = d + 1   # day of the year
    w = w + 1   # day of the week
    
    sol = solar.getday(d)   # solar power in Wh for each day (for 1 kW system)
    sol = sol * sizepv      # adjusting size of PV
    pvpro.append(sol)       # store PV production
    
    # first, we charge solar battery
    a = batsol.charge(sol)
    
    # second, the scooter is driving with it's own battery
    p = scooter.getday(w)
    batsco.discharge(p[0])
    a = batsco.state
    statesco.append(a)   # store min state of battery scooter
    
    # now, scooter needs to be charged
    # first, we check if there is enough solar power stored
    a = batsol.capa                     # this is how much we have
    x = batsco.capamax - batsco.capa    # this is how much the scooter could take
    if a >= x:
        batsol.discharge(x)
        batsco.charge(x)
        chargesco.append(x)      # store battery charge scooter
    else:
        batsol.discharge(a)
        batsco.charge(a)
        chargesco.append(a)         # store battery charge scooter
    
    a = batsol.state
    statepv.append(a)   # store min state of battery solar
    
    if w > 6:       # one week has 0..6 days
        w = 0
          
### END to read the data for one year ###

### create output for one month
# These are the number of days per month
days = []
days.append(0)  # This serves as starting point
days.append(31) # January 31 days
days.append(28) # Febr 28 days
days.append(31) # Mar 31 days
days.append(30) # Apr 30 days
days.append(31) # May 31 days
days.append(30) # Jun 30 days
days.append(31) # Jul 31 days
days.append(31) # Aug 31 days
days.append(30) # Sep 30 days
days.append(31) # Oct 31 days
days.append(30) # Nov 30 days
days.append(31) # Dec 30 days

mon = []
x = 0
for a in days:
    x = x + a
    mon.append(x)      # here, we create a list with increasing days (starting day for each month)
    
### create output for one year
x = range(1,366,1) # number of days from 1..365

m = 0
while m < 12:       # loop over all months
    
    a = mon[m]      # this marks the first day of the month
    b = mon[m+1]    # this marks the first day of the NEXT month
    dm = x[a:b]     # cut out the days for plotting from the year (x-values for plotting)
    m = m + 1

    pngfile = 'Energy-' + str(m) + '.png'		# file name for output

    fwidth = 10                 # figure width in cm 
    fwidth = fwidth / 2.54      # conversion inches to cm
    fheight = fwidth * 3/4		# using a ratio of 3/4 for height
    plt.subplots( figsize=( fwidth,fheight ) )  

    y = pvpro[a:b]
    plt.plot(dm, y, label='PV prod.')	# line plot 
    y = chargesco[a:b]
    plt.plot(dm, y, label='Charge scooter')	# line plot 

    plt.xlabel('Day')           # label x-axis
    plt.ylabel('Energy / Wh')    # label y-axis
    
    z = sizepv * 1000 # conversion from kW to W
    z = z * 8      # maximum value assumed full power for 8 hours
    plt.ylim(0,z)

    plt.legend(loc='upper right')
    plt.tight_layout()          # optimize placement
    plt.savefig(pngfile)        # create file for output
    plt.close()
    
    ### Here, we add a second plot for the state of battery
    pngfile = 'Battery-' + str(m) + '.png'		# file name for output
    plt.subplots( figsize=( fwidth,fheight ) )
    
    y = statepv[a:b]
    plt.plot(dm, y, label='PV')	# line plot 
    y = statesco[a:b]
    plt.plot(dm, y, label='Scooter')	# line plot 

    plt.xlabel('Day')           # label x-axis
    plt.ylabel('Battery state / %')    # label y-axis
    
    plt.ylim(0,100)
    plt.legend(loc='lower left') 
    plt.tight_layout()          # optimize placement
    plt.savefig(pngfile)        # create file for output
    plt.close()