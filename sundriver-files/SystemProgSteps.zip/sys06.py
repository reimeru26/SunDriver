"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, December 2025

"""
import batterysolar as batsol   # model for battery of PV panel
import batteryscooter as batsco # model for battery of scooter
import solar                    # model for PV panel
import scooter                  # model for scooter

import matplotlib.pyplot as plt

filescooter = [ 'day1.dat', 'day2.dat', 'day3.dat', 'day4.dat', 'day5.dat', 'day6.dat', 'day7.dat']
filesolar = ['Kochi-2023.csv', 'Emden-2023.csv']

# initialize models, read files
solar.readyear(filesolar[0])  # we choose data / 0 = Kochi and 1 = Emden

scooter.readweek(filescooter) # read driving cycle for scooter
batsco.capa = batsco.capamax  # we start with a fully charged scooter
batsco.state = 100.0

### System data collection ###
pvpro = []      # PV production per day
chargesco = []  # charge battery scooter
statepv = []    # state battery solar (min value)
statesco = []   # state battery scooter (min value)

### Control parameters ###
sizepv = 100.0 / 1000.0       # size of PV system in kW  results Kochi = 50 and Emden = 300

### START to read the data for one year ###
d = 0
w = 0
while d < 365:
    d = d + 1   # day of the year
    w = w + 1   # day of the week
    
    sol = solar.getday(d)   # solar power in Wh for each day (for 1 kW system)
    sol = sol * sizepv      # adjusting size of PV
    pvpro.append(sol)       # store PV production
    
    # first, we charge solar battery
    a = batsol.charge(sol)
    
    # second, the scooter is driving with it's own battery
    p = scooter.getday(w)
    batsco.discharge(p[0])
    a = batsco.state
    statesco.append(a)   # store min state of battery scooter
    
    # now, scooter needs to be charged
    # first, we check if there is enough solar power stored
    a = batsol.capa                     # this is how much we have
    x = batsco.capamax - batsco.capa    # this is how much the scooter could take
    if a >= x:
        batsol.discharge(x)
        batsco.charge(x)
        chargesco.append(x)      # store battery charge scooter
    else:
        batsol.discharge(a)
        batsco.charge(a)
        chargesco.append(a)         # store battery charge scooter
    
    a = batsol.state
    statepv.append(a)   # store min state of battery solar
    
    if w > 6:       # one week has 0..6 days
        w = 0
          
### END to read the data for one year ###

### create example output
x = range(1,366,1) # number of days from 1..365

pngfile = 'Energy.png'		# file name for output

fwidth = 10                 # figure width in cm 
fwidth = fwidth / 2.54      # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
plt.subplots( figsize=( fwidth,fheight ) )  

plt.plot(x, pvpro, label='PV prod.')	# line plot 
plt.plot(x, chargesco, label='Charge scooter')	# line plot 

plt.xlabel('Day')           # label x-axis
plt.ylabel('Energy / Wh')    # label y-axis

plt.legend()
plt.tight_layout()          # optimize placement
plt.savefig(pngfile)        # create file for output