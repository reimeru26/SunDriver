"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, December 2025

"""

capamax = 480.0     # max capacity
capa = 0.0          # how much is charged
state = 0.0         # percent charged

    
def charge(p):
    # charging the battery
    # the return value gives the amount of energy actually stored
    global capa, capamax, state
    
    # check, how much could be stored
    a = capamax - capa
    
    if p > a:  # you cannot charge more
        capa = capamax
        state = 100.0
        return a
    else:
        capa = capa + p
        state = 100.0 * capa / capamax
        return p
        
def discharge(p):
    # discharging the battery
    global capa, capamax, state
    
    if p > capa:  # you cannot discharge more
        p = capa 
        capa = 0.0
        state = 0.0
        return p
    else:
        capa = capa - p
        state = 100.0 * capa / capamax
        return p