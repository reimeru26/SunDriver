"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, December 2025

"""

capamax = 480.0     # max capacity / Wh
capa = 0.0          # how much is stored / Wh
state = 0.0         # percent charged

    
def charge(p):
    # charging the battery
    global capa, capamax, state
    
    capa = capa + p
    state = 100.0 * capa / capamax
        
def discharge(p):
    # discharging the battery
    global capa, capamax, state
    
    capa = capa - p
    state = 100.0 * capa / capamax
    
    