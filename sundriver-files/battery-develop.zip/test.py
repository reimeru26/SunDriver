"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Test the battery model
"""

import bat01 as bat

# read, what is maximum
x = bat.capamax
print('max. charge is ', x)

# charging battery
p = x
bat.charge(p)

# test, if fully charged
print('battery state in %: ', bat.state)

# discharge battery
p = 240.0
bat.discharge(p)
print('battery state in %: ', bat.state)


# try again 
p = 400.0
bat.discharge(p)
print('battery state in %: ', bat.state)
