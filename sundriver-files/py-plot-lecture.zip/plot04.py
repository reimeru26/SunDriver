"""
This is an example script for the lecture "Modelling and Simulation".
Introduction of simple plots

Uwe Reimer, Emden, November 2025
"""

import matplotlib.pyplot as plt

### y-data
y1dat = [6,5,3,1,1,1,0]      # data for ToDo
y2dat = [0,0,0,2,3,4,6]      # data for Done
### x-data
a = len(y1dat)
xdat = range(a)     # create a list with integers from zero to a

### This section is for plotting
pngfile = 'Plot04.png'		# file name for output

fwidth = 10                 # figure width in cm 
fwidth = fwidth / 2.54        # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
plt.subplots( figsize=( fwidth,fheight ) )  

plt.plot(xdat, y1dat, label='ToDo')	# line plot data1
plt.plot(xdat, y2dat, label='Done') # line plot data2

plt.xlabel('time step')             # label x-axis
plt.ylabel('Work packages (Cards)') # label y-axis

plt.legend()   				# legend - needs label in plots
plt.tight_layout()          # optimize placement
plt.savefig(pngfile)        # create file for output

