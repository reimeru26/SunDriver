"""
This is an example script for the lecture "Modelling and Simulation".
Introduction of simple plots

Uwe Reimer, Emden, November 2025
"""

import matplotlib.pyplot as plt

### generate curves
xdat = range(10)
y1dat = []
y2dat = []

for x in xdat:
    a = x * x       # Returns square of x 
    y1dat.append(a)
    a = x
    y2dat.append(a)
    
### This section is for plotting
pngfile = "Plot09.png"                     # file name for output

fwidth = 10                 # figure width in cm 
fwidth = fwidth / 2.54        # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
fig, ax1 =plt.subplots( figsize=( fwidth,fheight ) )  

ax2 = plt.twinx(ax1)    # define second y-axis with the same x-axis as base

ax1.set_xlabel('x-value')
ax1.set_ylabel('y = x$^2$')
ax2.set_ylabel('y = x')

ax1.tick_params(axis='both')

ax1.plot(xdat, y1dat, label='left side')
ax2.plot(xdat, y2dat, label='right side')
          
ax1.set_ylim(0.0 , 80.0)
ax2.set_ylim(0.0 , 10.0)

fig.legend(loc='upper center', shadow=True)
fig.tight_layout()                          # optimize placement
fig.savefig(pngfile)                        # create file for output

