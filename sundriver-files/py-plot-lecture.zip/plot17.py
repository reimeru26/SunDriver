"""
This is an example script for the lecture "Modelling and Simulation".
Introduction of simple plots

Uwe Reimer, Emden, November 2025
"""

import matplotlib.pyplot as plt
import random

# -----------  color definition ----------- #
m_col = []  # 
m_col.append("#000000") # 0 black
m_col.append("#38761d") # 1 green
m_col.append("#1155cc") # 2 blue
m_col.append("#cc0000") # 3 red
m_col.append("#ff9900") # 4 orange
m_col.append("#ffff00") # 5 yellow
m_col.append("#00ff00") # 6 neon green
m_col.append("#00ffff") # 7 cyan
m_col.append("#ff00ff") # 8 magenta
m_col.append("#9900ff") # 9 purple
m_col.append("#0000ff") # 10 blue 2
m_col.append("#cccccc") # 11 grey light
m_col.append("#666666") # 12 grey dark


xdat = range(10)
y1dat = []
y2dat = []
y3dat = []

for x in xdat:
    a = 5.0 + 5.0 * random.random() # Returns a random floating point number between 0 and 1
    y1dat.append(a)
    a = 6.0 + 5.0 * random.random()
    y2dat.append(a)
    a = 4.0 + 5.0 * random.random() 
    y3dat.append(a)
    

### This section is for plotting
pngfile = "Plot17.png"                      # file name for output

fwidth = 10                 # figure width in cm 
fwidth = fwidth / 2.54        # conversion inches to cm
fheight = fwidth * 3/4		# using a ratio of 3/4 for height
plt.subplots( figsize=( fwidth,fheight ) ) 

plt.plot(xdat, y1dat, label="y1", color=m_col[0])         # line plot data1
plt.plot(xdat, y2dat, label="y2", color=m_col[1])
plt.plot(xdat, y3dat, label="y3", color=m_col[2])

plt.scatter(xdat, y1dat, color=m_col[0])
plt.scatter(xdat, y2dat, color=m_col[1])
plt.scatter(xdat, y3dat, color=m_col[2])

plt.xlabel("time step")       # label x-axis
plt.ylabel("y-value")         # label y-axis

plt.ylim(0,15)

plt.legend(loc=(1.03,0.7), shadow=True)   # place legend - needs label in plots
plt.tight_layout()                          # optimize placement
plt.savefig(pngfile)                        # create fiel for output

