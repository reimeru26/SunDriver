"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: anaylzing the input file
Step 2: reading a file
Step 3: converting text to numbers
Step 4: create list for sum of power for each day
Step 5: create a function -> readyear()
Step 6: create a function -> getday()
"""

infile = 'Emden-2023.csv'   # file name
pday = []                   # sum of power for each day of the year

def readyear(infile):
    # function to read file with data for one year and calculate sums per day
    global pday
    
    if len(pday) > 0:       # if there is 'old' data
        del pday[0:]        # delete all entries

    myin = open(infile, 'r')     # open a text file in read mode
    mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
    myin.close()

    # remove header line from list / there are 11 lines
    del mytext[0:11]   

    # remove lines at the end / there are also 11 lines
    b = len(mytext)
    a = b - 11
    del mytext[a:b]

    # convert text to numbers 
    pall = []

    for a in mytext:
        b = a.split(',')
        p = float( b[1] )
        pall.append(p)
        
    # create list of power for each day
    h = 0
    p = 0
    for a in pall:
        p = p + a       # sum power
        h = h + 1       # sum hour
        
        if h == 24:     # this is one day
            pday.append(p)  # store sum for day
            p = 0
            h = 0
    
def getday(day):
    # function to retrieve sum of power for one day of the year
    global pday
    
    day = day - 1 # internal count starts with zero
    p = pday[day]
    return p