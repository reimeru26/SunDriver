import solar

file1 = 'Emden-2023.csv'
file2 = 'Kochi-2023.csv'

# These are the number of days per month
days = []
days.append(0) # This serves as starting point
days.append( 31 ) # January 31 days
days.append( 28 ) # Febr 28 days
days.append( 31 ) # Mar 31 days
days.append( 30 ) # Apr 30 days
days.append( 31 ) # May 31 days
days.append( 30 ) # Jun 30 days
days.append( 31 ) # Jul 31 days
days.append( 31 ) # Aug 31 days
days.append( 30 ) # Sep 30 days
days.append( 31 ) # Oct 31 days
days.append( 30 ) # Nov 30 days
days.append( 31 ) # Dec 30 days

mon = []
x = 0
for a in days:
    x = x + a
    mon.append(x)      # here, we create a list with increasing days (starting day for each month)
    
solar.readyear(file1) # initialize model, read data
year1 = []            # store results 

x = 0
while x < 12:
    a = mon[x]      # this marks the first day of the month
    b = mon[x+1]    # this marks the first day of the NEXT month
    x = x + 1
    
    c = solar.pday[a:b] # cut out only the days for one month
    p = 0
    for d in c:         # sum over one month
        p = p + d
    
    year1.append(p)     # store sum in list

# check the result - should be 12 months
print( len(year1) )