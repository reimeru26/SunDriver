import solar

file1 = 'Emden-2023.csv'
file2 = 'Kochi-2023.csv'

# These are the number of days per month
days = []
days.append(0) # This serves as starting point
days.append( 31 ) # January 31 days
days.append( 28 ) # Febr 28 days
days.append( 31 ) # Mar 31 days
days.append( 30 ) # Apr 30 days
days.append( 31 ) # May 31 days
days.append( 30 ) # Jun 30 days
days.append( 31 ) # Jul 31 days
days.append( 31 ) # Aug 31 days
days.append( 30 ) # Sep 30 days
days.append( 31 ) # Oct 31 days
days.append( 30 ) # Nov 30 days
days.append( 31 ) # Dec 30 days

mon = []
x = 0
for a in days:
    x = x + a
    mon.append(x)
    
print(mon)
