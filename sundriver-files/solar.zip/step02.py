"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: anaylzing the input file
Step 2: reading a file
"""

infile = 'Emden-2023.csv' # file name

myin = open(infile, 'r')  # open a text file in read mode
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

# remove header line from list / there are 11 lines
del mytext[0:11]   

# remove lines at the end / there are also 11 lines
b = len(mytext)
a = b - 11
del mytext[a:b]

print( mytext[0] )      # check first line
  