"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: anaylzing the input file
Step 2: reading a file
Step 3: converting text to numbers
"""

infile = 'Emden-2023.csv' # file name

myin = open(infile, 'r')  # open a text file in read modus
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

# remove header line from list / there are 11 lines
del mytext[0:11]   

# remove lines at the end / there are also 11 lines
b = len(mytext)
a = b - 11
del mytext[a:b]

# Step 3: convert text to numbers 

pall = []       # create a list to collect power data

for a in mytext:
    b = a.split(',')        # split at comma
    p = float( b[1] )       # convert second column - this is the power data in W
    pall.append(p)          # add to list
    
# check list
print( len(pall) )      # there should be 8760 entries = 365 * 24 hours
  