"""
This is an example script for the lecture "Modelling and Simulation"
Uwe Reimer, Emden, November 2025

Step 1: anaylzing the input file
Step 2: reading a file
Step 3: converting text to numbers
Step 4: create list for sum of power for each day
"""

infile = 'Emden-2023.csv' # file name

myin = open(infile, 'r')  # open a text file in read modus
mytext = myin.readlines()    # here, we read the entire file into a list of strings (each line is one item)
myin.close()

# remove header line from list / there are 11 lines
del mytext[0:11]   

# remove lines at the end / there are also 11 lines
b = len(mytext)
a = b - 11
del mytext[a:b]

# Step 3: convert text to numbers 
pall = []       # create a list to collect power data

for a in mytext:
    b = a.split(',')        # split at comma
    p = float( b[1] )       # convert second column - this is the power data in W
    pall.append(p)          # add to list
    

# Step 4: create list for sum of power for each day
pday = []

h = 0
p = 0
for a in pall:

    p = p + a       # sum power
    h = h + 1       # sum hour
    
    if h == 24:     # this is one day
        pday.append(p)  # store sum for day
        p = 0
        h = 0
    
print( len(pday) )  # check the list